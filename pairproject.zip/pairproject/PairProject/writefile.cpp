#include"a.h"
void WriteFormula(string s, int i)
{
	ofstream ofs;
	ofs.open("Exercises.txt", ios::app);
	ofs << i << "." << "����������Ŀ" << "  ";
	ofs << s << endl;
	ofs.close();
}
void WriteAnswer(Num ans, int i)
{
	ofstream ofs;
	ofs.open("Answers.txt", ios::app);
	ofs << i << "." << "��" << "  ";
	if (ans.denominator != 1)
		ofs << ans.molecule << '/' << ans.denominator << endl;
	else ofs << ans.molecule << endl;
	ofs.close();
}